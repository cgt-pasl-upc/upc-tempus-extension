export default class ScrapperException extends Error {
    constructor(message) {
        super(message);
    }
}
